@extends('layouts.fenex')
@section('title', 'Edit an Product')

@section('content')
<div class="container py-4">
    <h1>Edit Product</h1>
    <form action="{{ route('products.update', $product) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div class="mb-3">
            <label for="name" class="form-label">Product Name</label>
            <input type="text" class="form-control" id="name" name="name" value="{{ $product->name }}" required>
        </div>
        <div class="mb-3">
            <label for="cost_of_goods" class="form-label">Cost of Goods</label>
            <input type="number" class="form-control" id="cost_of_goods" name="cost_of_goods" step="0.01" value="{{ $product->cost_of_goods }}" required>
        </div>
        <div class="mb-3">
            <label for="weight" class="form-label">Weight</label>
            <input type="number" class="form-control" id="weight" name="weight" step="0.01" value="{{ $product->weight }}" required>
        </div>
        <div class="mb-3">
            <label for="photo" class="form-label">Product Photo</label>
            <input type="file" class="form-control" id="photo" name="photo">
            @if($product->photo)
                <img src="{{ asset('storage/app/public/' . $product->photo) }}" width="100" class="mt-3">
            @endif
        </div>
        <button type="submit" class="btn btn-primary">Update Product</button>
    </form>
</div>
@endsection
