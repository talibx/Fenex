@extends('layouts.fenex')
@section('title', 'Add a Product')
@section('content')
<div class="container py-4">
    <h1>Add New Product</h1>
    <form action="{{ route('products.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="mb-3">
            <label for="name" class="form-label">Product Name</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="mb-3">
            <label for="cost_of_goods" class="form-label">Cost of Goods</label>
            <input type="number" class="form-control" id="cost_of_goods" name="cost_of_goods" step="0.01" required>
        </div>
        <div class="mb-3">
            <label for="weight" class="form-label">Weight</label>
            <input type="number" class="form-control" id="weight" name="weight" step="0.01" required>
        </div>
        <div class="mb-3">
            <label for="photo" class="form-label">Product Photo</label>
            <input type="file" class="form-control" id="photo" name="photo">
        </div>
        <button type="submit" class="btn btn-primary">Add Product</button>
    </form>
</div>
@endsection
