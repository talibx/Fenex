
@extends('layouts.fenex')
{{-- <x-app-layout> --}}
<style>
    .pagination {
           display: inline-block;
           padding-left: 0;
           margin: 20px 0;
           border-radius: 4px;
           justify-content: center;
       }
</style>
@section('title', 'Products')
@section('content')
<?php
// $all_items = 0;
// foreach($products as $product){
//     foreach ($product->inventory_quantities as $num_of_condition){
//         $all_items += $num_of_condition;
//     }
// }
?>
<div class="container-fluid py-4">
    
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-4">
        <h4 class="mb-2 mb-md-0">Products ( {{count($products)}} )</h4>
        <div class="text-center mb-2 mb-md-0">
            All items: {{--$all_items--}} {{$total_inventory}} | Total Cost: {{$total_cost}} AED
        </div>
        <a href="{{ route('products.create') }}" class="btn btn-sm btn-primary">Add New Product</a>
    </div>

    @if(session('success'))
        <div class="alert alert-success mt-3">{{ session('success') }}</div>
    @endif
       
    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-bordered table-striped">
                <thead class="table-primary">
                        <tr>
                            <th>Product Name</th>
                            <th>Photo</th>  
                            <th>Cost of Goods</th>
                            <th>weight</th>
                            <th>new</th>
                            <th>used</th>
                            <th>d/bag</th>
                            <th>no/bag</th>
                            <th>d/all</th>
                            <th>replaced</th>

                            <th><a href="{{ route('products.index', ['sort' => 'created_at']) }}">Created At</a></th>
                            <th><a href="{{ route('products.index', ['sort' => 'updated_at']) }}">Updated At</a></th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($products as $product)
                            <td>{{ $product->name }}</td>
                            <td class="text-center">
                                @if($product->photo)
                                    <img src="{{ asset('storage/app/public/' . $product->photo) }}" alt="{{ $product->name }}" class="img-thumbnail" style="max-width: 100px;">
                                @else
                                    No photo available
                                @endif
                            </td>
                            <td>{{ number_format($product->cost_of_goods, 0) }} AED </td>
                            <td>{{ number_format($product->weight, 2) }} KG </td>
                            <td>{{$product->inventory_quantities["new"]}}</td>
                            <td>{{$product->inventory_quantities["used in good condition"]}}</td>
                            <td>{{$product->inventory_quantities["damaged bag"]}}</td>
                            <td>{{$product->inventory_quantities["without bag"]}}</td>
                            <td>{{$product->inventory_quantities["damaged product"]}}</td>
                            <td>{{$product->inventory_quantities["replaced"]}}</td>
                            <td>{{ $product->created_at->format('M d, Y') }}</td>
                            <td>{{ $product->updated_at->diffForHumans() }}</td>
                            <td class="text-center">
                                <a href="{{ route('products.edit', $product) }}" class="btn btn-warning btn-sm me-2" title="Edit"><i class="bi bi-pencil"></i>Edit</a>
                                <!-- <form action="{{ route('products.destroy', $product) }}" method="POST" style="display:inline;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this product?')" title="Delete"><i class="bi bi-trash"></i>Delete</button>
                                </form> -->
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="3" class="text-center">No products found.</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="pagination">
                    <!-- want more detial see this : https://stackoverflow.com/questions/17159273/laravel-pagination-links-not-including-other-get-parameters -->
        {{ $products->appends(request()->except('page'))->links('pagination::bootstrap-4') }}
    </div>
</div>
@endsection
{{-- </x-app-layout> --}}
