@extends('layouts.fenex')

@section('content')
<div class="container">
    <h1>Product Details</h1>
    <div class="card">
        <div class="card-header">
            {{ $product->name }}
        </div>
        <div class="card-body">
            @if($product->photo)
                <img src="{{ asset('storage/app/public/' . $product->photo) }}" width="300">
            @else
                <p>No photo available</p>
            @endif
        </div>
    </div>
    <a href="{{ route('products.index') }}" class="btn btn-secondary mt-3">Back to Products</a>
</div>
@endsection
