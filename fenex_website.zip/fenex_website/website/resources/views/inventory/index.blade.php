<!-- resources/views/inventory/index.blade.php -->
@extends('layouts.fenex')
<style>
    .pagination {
           display: inline-block;
           padding-left: 0;
           margin: 20px 0;
           border-radius: 4px;
           justify-content: center;
       }
</style>

@section('title', 'Inventory')
@section('content')
<div class="container-fluid py-4">

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-4">
        <h4 class="mb-2 mb-md-0">Inventory ({{$total_inventory}})</h4>
        <div class="text-center mb-2 mb-md-0">
            Products ( {{count($products)}} ) | Total Cost : {{$total_cost}} AED
        </div>
        <a href="{{ route('inventory.create') }}" class="btn btn-sm btn-success">Add New Inventory Item</a>
    </div>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-bordered table-striped">
                    <thead class="table-success">
                        <tr>
                            <th>Product Name</th>
                            <th>Photo</th>  
                            <th>Inventory Actions</th>
                            <th>Quantity</th>
                            <th>Condition</th>
                            <th style="width: 20%">Notes</th>
                           
                            <th><a href="{{ route('inventory.index', ['sort' => 'created_at']) }}">Created At</a></th>
                            <th><a href="{{ route('inventory.index', ['sort' => 'updated_at']) }}">Updated At</a></th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($inventory as $item)
                        <tr>
                            <td>{{ $item->product->name }}</td>
                            <td>
                                @if($item->product->photo)
                                    <img src="{{ asset('storage/app/public/' . $item->product->photo) }}" alt="{{ $item->product->name }}" class="img-thumbnail" style="max-width: 75px;max-width: 100px;">
                                @else
                                    No photo available
                                @endif
                            </td>
                            <td>{{ ucfirst($item->inventory_actions) }}</td>

                            @if($item->quantity <= 0)  
                                <td style='color: red !important;font-weight:bold'>
                                    {{ $item->quantity }}
                                </td>    
                            @else
                                <td style='color: green !important;font-weight:bold'>
                                    {{ $item->quantity }}
                                </td>  
                            @endif  

                            <td>{{ ucfirst($item->condition) }}</td>

                            {{-- <td>{{ ucfirst($item->notes) }}</td> --}}

                            <td>
                                <span id="notes" data-fulltext="{{$item->notes}}">
                                    {{$item->notes}}
                                </span>
                                <a id="read-more" href="javascript:void(0);" onclick="toggleReadMore(this)">Read More</a>
                            </td>
                            
                            <script>
                                function toggleReadMore(link) {
                                    const span = link.previousElementSibling;
                                    const fullText = span.innerText;
                                    const shortText = fullText.substring(0, 50) + '...';
                            
                                    if (link.innerText === "Read More") {
                                        span.innerText = span.dataset.fulltext;     // Show full text
                                        link.innerText = "Read Less";   // Toggle link text
                                    } else {
                                        span.innerText = shortText;     // Show truncated text
                                        link.innerText = "Read More";   // Toggle link text back
                                    }
                                }
                            
                                // Initial setup for truncation
                                document.querySelectorAll('#notes').forEach(span => {
                                    const fullText = span.innerText;
                                    if (fullText.length > 50) {
                                        span.innerText = fullText.substring(0, 50) + '...';
                                    }else{
                                        span.innerText = fullText;
                                        span.nextElementSibling.style.display = 'none';
                                    }
                                });
                            </script>
                            

                            <td>{{ $item->created_at->format('M d, Y') }}</td>
                            <td>{{ $item->updated_at->diffForHumans() }}</td>
                            <td class="text-center">
                                <a href="{{ route('inventory.edit', $item) }}" class="btn btn-warning btn-sm me-2" title="Edit"><i class="bi bi-pencil"></i>Edit</a>
                                <form action="{{ route('inventory.destroy', $item) }}" method="POST" style="display:inline;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this Inventory?')" title="Delete"><i class="bi bi-trash"></i>Delete</button>
                                </form>
                            </td>
                        </>
                        @endforeach
                    </tbody>
                </table>
            </div>    
        </div>
    </div>
    <div class="pagination">
                    <!-- want more detial see this : https://stackoverflow.com/questions/17159273/laravel-pagination-links-not-including-other-get-parameters -->
        {{ $inventory->appends(request()->except('page'))->links('pagination::bootstrap-4') }}
    </div>

    <!-- <div class="mt-4">
        {{ $inventory->appends(request()->except('page'))->links() }}
    </div> -->
</div>
@endsection
