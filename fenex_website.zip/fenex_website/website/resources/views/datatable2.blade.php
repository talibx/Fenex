<!doctype html>

<?php


/*
 * Editor server script for DB table products
 * Created by http://editor.datatables.net/generator
 */

// DataTables PHP library and database connection
include( "lib/DataTables.php" );

// Alias Editor classes so they are easy to use
use
	DataTables\Editor,
	DataTables\Editor\Field,
	DataTables\Editor\Format,
	DataTables\Editor\Mjoin,
	DataTables\Editor\Options,
	DataTables\Editor\Upload,
	DataTables\Editor\Validate,
	DataTables\Editor\ValidateOptions;

// The following statement can be removed after the first run (i.e. the database
// table has been created). It is a good idea to do this to help improve
// performance.
$db->sql( "CREATE TABLE IF NOT EXISTS `products` (
	`id` int(10) NOT NULL auto_increment,
	`product_name` varchar(255),
	`photo` varchar(255),
	`cost_of_goods` numeric(9,2),
	`weight` numeric(9,2),
	`new` numeric(9,2),
	`used` numeric(9,2),
	`dbag` numeric(9,2),
	`nobag` numeric(9,2),
	`dall` numeric(9,2),
	`replaced` numeric(9,2),
	PRIMARY KEY( `id` )
);" );

// Build our Editor instance and process the data coming from _POST
Editor::inst( $db, 'products', 'id' )
	->fields(
		Field::inst( 'product_name' ),
		Field::inst( 'photo' ),
		Field::inst( 'cost_of_goods' ),
		Field::inst( 'weight' ),
		Field::inst( 'new' ),
		Field::inst( 'used' ),
		Field::inst( 'dbag' ),
		Field::inst( 'nobag' ),
		Field::inst( 'dall' ),
		Field::inst( 'replaced' )
	)
	->process( $_POST )
	->json();

?>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		
		<title>DataTables Editor - products</title>

		<link rel='stylesheet' type='text/css' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css'/>
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs5/jq-3.7.0/moment-2.29.4/jszip-3.10.1/dt-2.1.6/af-2.7.0/b-3.1.2/b-colvis-3.1.2/b-html5-3.1.2/b-print-3.1.2/cr-2.0.4/date-1.5.4/fc-5.0.1/fh-4.0.1/kt-2.12.1/r-3.0.3/rg-1.5.0/rr-1.5.0/sc-2.4.3/sb-1.8.0/sp-2.3.2/sl-2.1.0/sr-1.4.1/datatables.min.css">
		<link rel="stylesheet" type="text/css" href="css/generator-base.css">
		<link rel="stylesheet" type="text/css" href="css/editor.bootstrap5.min.css">

		<script type="text/javascript" charset="utf-8" src="https://cdn.datatables.net/v/bs5/jq-3.7.0/moment-2.29.4/jszip-3.10.1/dt-2.1.6/af-2.7.0/b-3.1.2/b-colvis-3.1.2/b-html5-3.1.2/b-print-3.1.2/cr-2.0.4/date-1.5.4/fc-5.0.1/fh-4.0.1/kt-2.12.1/r-3.0.3/rg-1.5.0/rr-1.5.0/sc-2.4.3/sb-1.8.0/sp-2.3.2/sl-2.1.0/sr-1.4.1/datatables.min.js"></script>
		<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js'></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script><script type="text/javascript" charset="utf-8" src="js/dataTables.editor.min.js"></script>
		<script type="text/javascript" charset="utf-8" src="js/editor.bootstrap5.min.js"></script>
		<script type="text/javascript" charset="utf-8" src="js/table.products.js"></script>
	</head>
	<body class="bootstrap5">
		<div class="container">

			<h1>
				DataTables Editor <span>products</span>
			</h1>
			
			<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="products" width="100%">
				<thead>
					<tr>
						<th>Product Name</th>
						<th>Photo</th>
						<th>Cost of Goods</th>
						<th>weight</th>
						<th>new</th>
						<th>used</th>
						<th>d/bag</th>
						<th>no/bag</th>
						<th>d/all</th>
						<th>replaced</th>
					</tr>
				</thead>
			</table>

		</div>
	</body>
</html>


<script>

    
/*
 * Editor client script for DB table products
 * Created by http://editor.datatables.net/generator
 */

addEventListener("DOMContentLoaded", function () {
	var editor = new DataTable.Editor( {
		ajax: 'php/table.products.php',
		table: '#products',
		fields: [
			{
				"label": "Product Name:",
				"name": "product_name"
			},
			{
				"label": "Photo:",
				"name": "photo"
			},
			{
				"label": "Cost of Goods:",
				"name": "cost_of_goods"
			},
			{
				"label": "weight:",
				"name": "weight"
			},
			{
				"label": "new:",
				"name": "new"
			},
			{
				"label": "used:",
				"name": "used"
			},
			{
				"label": "d\/bag:",
				"name": "dbag"
			},
			{
				"label": "no\/bag:",
				"name": "nobag"
			},
			{
				"label": "d\/all:",
				"name": "dall"
			},
			{
				"label": "replaced:",
				"name": "replaced"
			}
		]
	} );

	var table = new DataTable('#products', {
		ajax: 'php/table.products.php',
		columns: [
			{
				"data": "product_name"
			},
			{
				"data": "photo"
			},
			{
				"data": "cost_of_goods"
			},
			{
				"data": "weight"
			},
			{
				"data": "new"
			},
			{
				"data": "used"
			},
			{
				"data": "dbag"
			},
			{
				"data": "nobag"
			},
			{
				"data": "dall"
			},
			{
				"data": "replaced"
			}
		],
		layout: {
			topStart: {
				buttons: [
					{ extend: 'create', editor: editor },
					{ extend: 'edit', editor: editor },
					{ extend: 'remove', editor: editor }
				]
			}
		},
		select: true
	});
});

</script>