<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Inventory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    public function index(Request $request) {
        // Determine the column to sort by and the direction of sorting
        $sortBy = $request->get('sort') ?: 'created_at'; // Default sort by 'created_at'
        $sortDirection = $request->get('direction') ?: 'asc'; // Default direction 'asc'

        // Fetch products with their related inventories using eager loading
        // and apply sorting and pagination
        $products = Product::with('inventories')->orderBy($sortBy, $sortDirection)->paginate(100);
        $total_inventory=0;
        $total_cost=0;

        // Iterate over each product to calculate inventory quantities by condition
        foreach ($products as $product) {
            // Initialize an array to store quantities for each inventory condition
            $product_inventory = [
                'new' => 0,
                'used in good condition' => 0,
                'damaged bag' => 0,
                'damaged product' => 0,
                'without bag' => 0,
                'replaced' => 0
            ];
            

            // Loop through each inventory record related to the current product
            foreach ($product->inventories as $inventory) {
                // Accumulate the quantity for the specific condition
                $product_inventory[$inventory->condition] += $inventory->quantity;

                // Get All count of the products from all conndition
                $total_inventory += $inventory->quantity;
                // Get Total cost of goods of the all items
                // we access ->product throught the relation bewteen the two table using the name of function
                $total_cost += $inventory->quantity * $inventory->product->cost_of_goods;

            }

            // Attach the calculated inventory quantities to the product
            $product->inventory_quantities = $product_inventory;
        }

        // Return the products index view with the products and sorting information
        return view('products.index', compact('products', 'sortBy', 'sortDirection','total_inventory','total_cost'));
    }



    public function create()
    {
        return view('products.create');
    }

    // public function store(Request $request)
    // {
    //     $request->validate([
    //         'name' => 'required',
    //         'photo' => 'nullable|image|max:2048',
    //     ]);

    //     $photoPath = null;
    //     if ($request->hasFile('photo')) {
    //         $photoPath = $request->file('photo')->store('photos', 'public');
    //     }

    //     Product::create([
    //         'name' => $request->name,
    //         'photo' => $photoPath,
    //     ]);

    //     return redirect()->route('products.index')->with('success', 'Product created successfully.');
    // }

    
    
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'cost_of_goods' => 'required|numeric',
            'weight' => 'required|numeric',
            'photo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        $product = new Product();
        $product->name = $request->name;
        $product->weight = $request->weight;
        $product->cost_of_goods = $request->cost_of_goods;

        if ($request->hasFile('photo')) {
            $product->photo = $request->file('photo')->store('products', 'public');
        }

        $product->save();

        return redirect()->route('products.index')->with('success', 'Product created successfully.');
    }
    
    
    
    public function show(Product $product)
    {
        return view('products.show', compact('product'));
    }

    public function edit(Product $product)
    {
        return view('products.edit', compact('product'));
    }

    // public function update(Request $request, Product $product)
    // {
    //     $request->validate([
    //         'name' => 'required',
    //         'photo' => 'nullable|image|max:2048',
    //     ]);

    //     if ($request->hasFile('photo')) {
    //         if ($product->photo) {
    //             Storage::disk('public')->delete($product->photo);
    //         }
    //         $product->photo = $request->file('photo')->store('photos', 'public');
    //     }

    //     $product->update([
    //         'name' => $request->name,
    //         'photo' => $product->photo,
    //     ]);

    //     return redirect()->route('products.index')->with('success', 'Product updated successfully.');
    // }

   
   
    public function update(Request $request, Product $product)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'cost_of_goods' => 'required|numeric',
            'weight' => 'required|numeric',
            'photo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        $product->name = $request->name;
        $product->weight = $request->weight;
        $product->cost_of_goods = $request->cost_of_goods;


        if ($request->hasFile('photo')) {
            // Delete the old photo if it exists
            if ($product->photo) {
                Storage::disk('public')->delete($product->photo);
            }
            $product->photo = $request->file('photo')->store('products', 'public');
        }

        $product->save();

        return redirect()->route('products.index')->with('success', 'Product updated successfully.');
    }
   
   
    public function destroy(Product $product)
    {
        if ($product->photo) {
            Storage::disk('public')->delete($product->photo);
        }
        $product->delete();
        return redirect()->route('products.index')->with('success', 'Product deleted successfully.');
    }
}
