<?php
namespace App\Http\Controllers;

use App\Models\Inventory;
use App\Models\Product;
use Illuminate\Http\Request;

class InventoryController extends Controller
{
    public function index(Request $request)
    {
        $sortBy = $request->get('sort') ?: 'created_at'; // Default sort by created_at
        $sortDirection = $request->get('direction') ?: 'desc'; // Default direction asc

        $inventory = Inventory::with('product')
        ->orderBy($sortBy, $sortDirection)
        ->paginate(10);

        // Fetch products with their related inventories using eager loading
        // and apply sorting and pagination
        $products = Product::with('inventories')->get();
        $total_inventory=0;
        $total_cost=0;

        // Iterate over each product to calculate inventory quantities by condition
        foreach ($products as $product) {
            // Loop through each inventory record related to the current product
            foreach ($product->inventories as $p_inventory) {
                // Get All count of the products from all conndition
                $total_inventory += $p_inventory->quantity;
                // Get Total cost of goods of the all items
                // we access ->product throught the relation bewteen the two table using the name of function
                $total_cost += $p_inventory->quantity * $p_inventory->product->cost_of_goods;
            }
        }




        return view('inventory.index', compact('inventory', 'sortBy', 'sortDirection','products', 'sortDirection','total_inventory','total_cost'));
    }

    public function create()
    {
        $products = Product::all();
        return view('inventory.create', compact('products'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer',
            'condition' => 'required|in:new,used in good condition,damaged product,damaged bag,without bag,replaced',
            'inventory_actions' => 'required|in:add to inventory,ship to amazon',
            // 'notes' => 'nullable|string',
        ]);
    
        // Prepare the data to be saved
        $data = $request->all();
    
        // Modify the quantity if the action is 'ship to amazon'
        if ($request->inventory_actions == 'ship to amazon') {
            $data['quantity'] = $request->quantity * -1;
        }
    
        // Create the inventory record
        Inventory::create($data);
    
        return redirect()->route('inventory.index')->with('success', 'Inventory item added successfully.');
    }
    

    public function show(Inventory $inventory)
    {
        return view('inventory.show', compact('inventory'));
    }

    public function edit(Inventory $inventory)
    {
        $products = Product::all();
        return view('inventory.edit', compact('inventory', 'products'));
    }

    public function update(Request $request, Inventory $inventory)
    {
        $request->validate([
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer',
            'condition' => 'required|in:new,used in good condition,damaged product,damaged bag,without bag,replaced',
            'inventory_actions' => 'required|in:add to inventory,ship to amazon',
            // 'notes' => 'nullable|string',
        ]);
    
        // Prepare the data to be updated
        $data = $request->all();
        // dd($data);
        // Modify the quantity if the action is 'ship to amazon'
        if ($request->inventory_actions == 'ship to amazon') {
            $data['quantity'] = $request->quantity * -1;
        }
    
        // Update the inventory record
        $inventory->update($data);
    
        return redirect()->route('inventory.index')->with('success', 'Inventory item updated successfully.');
    }
    

    public function destroy(Inventory $inventory)
    {
        $inventory->delete();
        return redirect()->route('inventory.index')->with('success', 'Inventory item deleted successfully.');
    }
}
